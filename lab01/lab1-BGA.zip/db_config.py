# Database Configuration for University Performance Analysis
# Update these values according to your PostgreSQL setup

DB_CONFIG = {
    'host': 'localhost',
    'database': 'uni',
    'user': 'postgres',
    'password': 'usman9522',
    'port': 5432
}
